console.document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const number = document.getElementById("number").value;

  alert(`Thank you, ${name}! Your message has been received.\nEmail: ${email}\nContact: ${number}`);
});log("from script file");